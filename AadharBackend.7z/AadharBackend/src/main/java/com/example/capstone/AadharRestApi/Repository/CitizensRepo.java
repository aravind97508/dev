package com.example.capstone.AadharRestApi.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.capstone.AadharRestApi.Entity.Citizens;

public interface CitizensRepo extends CrudRepository<Citizens, Integer>{

}
