public class arrayrotation {

}
